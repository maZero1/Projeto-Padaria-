# Sistema de Padaria com Programa de Fidelidade (Swing + MVC)

Atende aos requisitos do PDF:
- **Produtos** (CRUD; estoque; flag *resgatável* e custo em pontos)
- **Clientes** (CRUD; nome, CPF, telefone, **saldo de pontos**)
- **Vendas** (múltiplos itens; escolher cliente; **paga**; atualiza estoque; **acumula pontos 1 ponto a cada R$10**)
- **Troca de Pontos** (resgate de produtos marcados como resgatáveis; verifica estoque e saldo; atualiza ambos)
- **Regras de negócio** do PDF implementadas.

> Os **DAOs e a conexão com BD** ficaram **stubs em branco**, prontos para você implementar o PostgreSQL depois.
> O sistema roda com **serviços em memória** para a apresentação.

## Como abrir no NetBeans
1. **File → Open Project…**
2. Selecione esta pasta (onde está o `pom.xml`).
3. Rode `AppMain`.

## Estrutura
- `model/` entidades (Produto, Cliente, Venda, ItemVenda)
- `service/` repositórios em memória e regras de negócio (estoque, pontos, resgate)
- `dao/` **stubs em branco** (interfaces + classes vazias)
- `controller/` coordena a View e os serviços
- `view/` Swing (telas de Produtos, Clientes, Vendas e Resgate de Pontos)
- `util/` máscaras, validações simples

## Regra de Pontos
- Somente **vendas pagas** acumulam pontos.
- **1 ponto por R$ 10,00** do total da venda (floor).
- Produtos **resgatáveis** possuem `custoPontos`.
- Resgate: exige estoque > 0 e pontos suficientes do cliente.

